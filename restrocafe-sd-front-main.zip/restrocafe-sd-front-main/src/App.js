import React from 'react'
import Router from './Router'
import "./assets/style.css"

function App() {
  return (
    <Router />
  );
}

export default App;
